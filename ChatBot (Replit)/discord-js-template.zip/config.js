module.exports = {
  prefix: '/',
  token: process.env.TOKEN
};